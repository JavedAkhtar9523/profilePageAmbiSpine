import React from "react";
import "../Styles/Banner.css";
import banner from "../Images/8.jpg";
import avtar from "../Images/admin.png";

const Banner = () => {
  return (
    <div>
      <div className="banner_img">
        <img src={banner} alt="" />
        <div className="banner_profile">
          <img src={avtar} alt="" />
        </div>
      </div>
    </div>
  );
};

export default Banner;
