import React from "react";

const Home = () => {
  return (
    <div style={{ marginLeft: "50%" }}>
      <h1>Home</h1>
    </div>
  );
};

export default Home;
