import React from "react";
import "../Styles/Input.css";
import Banner from "./Banner";

const Input = () => {
  return (
    <>
      <div className="contain">
        <Banner />
        <div className="input">
          <input type="text" placeholder="Enter Your Name..." />
          <input type="text" placeholder="Additional Name..." />
          <input type="text" placeholder="Location" />
          {/* <input type="text" placeholder="State & City" /> */}
          <select name="" id="" className="state">
            <option value="">--Select State--</option>
            <option value="bihar">Bihar</option>
            <option value="uttarpradesh">Uttar Pradesh</option>
            <option value="madhyapradesh">Madhya Pradesh</option>
          </select>
          <select name="" id="" className="district">
            <option value="">--Select District--</option>
            <option value="siwan">Siwan</option>
            <option value="saran">Saran</option>
            <option value="patna">Patna</option>
          </select>
          <input type="text" placeholder="Website" />
          <textarea name="" id="" placeholder="Bio..."></textarea>
          <div className="category">
            <p>Category</p>
            <button>+</button>
          </div>
          <div className="save_btn">
            <button>Save</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Input;
